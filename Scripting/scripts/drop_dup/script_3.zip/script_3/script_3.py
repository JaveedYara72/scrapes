import pandas as pd
import numpy as np

# 1st part - Read ASINS
excel_file = 'netsuite_item_master.csv'
common_columns = ['sku_id','brand_name','sku_id_alias','sku_id_alias2','sku_id_alias3','sku_id_alias4']

sku_id = pd.read_csv(excel_file)
sku_id = sku_id.loc[:, common_columns]

# sku_id['mapping'] = np.where(sku_id.iloc[:, 2:].notna().any(axis=1),
#                             sku_id.iloc[:, 2:].apply(lambda row: '-'.join(row[row.notnull()]), axis=1),
#                             sku_id['sku_id'])

# sku_id.to_csv('sku_id.csv')

# Create a new DataFrame to store the updated rows
updated_rows = []

# Iterate over each row in the DataFrame
for _, row in sku_id.iterrows():
    # Iterate over the last 4 columns
    for i in range(2, 6):
        value = row.iloc[i]
        if pd.notnull(value):
            # Create a new row with the non-null value
            new_row = row.copy()
            new_row['mapping'] = value
            # Append the new row to the updated_rows list
            updated_rows.append(new_row)

# Create a new DataFrame from the updated_rows list
mapped_sku_id = pd.DataFrame(updated_rows)

# Save the updated DataFrame to a CSV file
mapped_sku_id[['sku_id','brand_name' ,'mapping']].to_csv('mapped_sku_id.csv', index=False)

